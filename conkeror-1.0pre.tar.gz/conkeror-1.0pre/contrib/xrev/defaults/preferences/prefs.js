// default window.
pref("toolkit.defaultChromeURI", "chrome://xrev/content/main.xul");

// let us use the `dump' function.
pref("browser.dom.window.dump.enabled", true);

// prevent caching of XUL and JavaScript files.
pref("nglayout.debug.disable_xul_fastload", true);

