/**
 * (C) Copyright 2010 John J. Foerch
 *
 * Use, modification, and distribution are subject to the terms specified in the
 * COPYING file.
**/

define_fallthrough(content_buffer_embed_keymap, match_not_escape_key);
define_key(content_buffer_embed_keymap, match_not_escape_key, null, $fallthrough);
