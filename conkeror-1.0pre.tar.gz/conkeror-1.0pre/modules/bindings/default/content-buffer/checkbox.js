/**
 * (C) Copyright 2008 Martin Dybdal
 *
 * Use, modification, and distribution are subject to the terms specified in the
 * COPYING file.
**/

define_fallthrough(content_buffer_checkbox_keymap, match_checkbox_keys);

define_key(content_buffer_checkbox_keymap, "space", null, $fallthrough);

