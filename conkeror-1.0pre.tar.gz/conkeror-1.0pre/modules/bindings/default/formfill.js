/**
 * (C) Copyright 2010 John J. Foerch
 *
 * Use, modification, and distribution are subject to the terms specified in the
 * COPYING file.
**/

define_key(formfill_keymap, "C-n", "formfill-next");
define_key(formfill_keymap, "C-p", "formfill-previous");
